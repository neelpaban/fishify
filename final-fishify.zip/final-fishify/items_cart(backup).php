<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 50px;
            max-height: 50px;
        }
    </style>
</head>
<body>

<?php
session_start();
require_once("db_connection.php"); // Include your database connection code
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<?php
// Check if the session variable 'cart' is set
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    ?>
    <table>
        <thead>
        <tr>
            <th>Product ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Delete Items</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Loop through the cart items and display them
        foreach ($_SESSION['cart'] as $productId => $product) {
            
            ?>
            <tr>
                <td><?php echo $productId; ?></td>
                <td><img src="<?php echo $product['image_path']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"></td>
                <td><?php echo $product['name']; ?></td>
                <td>$<?php echo $product['price']; ?></td>
                <td><?php echo $product['quantity']; ?></td>
                <td><button class="delete-button" data-productid="<?php echo $productId; ?>">Delete</button></td>

            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    <?php
} else {
    echo "Cart is empty.";
}
?>
<!-- Include this script in the <head> section of your HTML or at the end of the body -->
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Add a click event listener to all delete buttons
    document.querySelectorAll('.delete-button').forEach(function (button) {
      button.addEventListener('click', function () {
        // Get the product ID from the data-productid attribute
        const productId = button.getAttribute('data-productid');

        // Send an AJAX request to delete the item
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'delete_cart_item.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        const data = new URLSearchParams();
        data.append('productId', productId);

        xhr.send(data);

        // Handle the response
        xhr.onload = function () {
          if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            if (response.status === 'success') {
              // Remove the corresponding table row
              const row = button.closest('tr');
              row.parentNode.removeChild(row);
            } else {
              console.error('Error deleting item:', response.message);
            }
          } else {
            console.error('An error occurred.');
          }
        };
      });
    });
  });
</script>




</body>
</html>
