<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "ecommerce";

$data = mysqli_connect($host, $user, $password, $db);

if ($data === false) {
    die("Connection error");
}

// Get the data from the form
$name = mysqli_real_escape_string($data, $_POST['name']); // Assuming you have a form field named 'name'
$email = mysqli_real_escape_string($data, $_POST['email']); // Assuming you have a form field named 'email'
$message = mysqli_real_escape_string($data, $_POST['message']); // Assuming you have a form field named 'message'

// Insert the data into the request_counter table
$insertQuery = "INSERT INTO request_counter (name, email, message) VALUES ('$name', '$email', '$message')";
mysqli_query($data, $insertQuery);

// Increment the request counter
$sql = "UPDATE request_counter SET count = count + 1 WHERE id = 1";
mysqli_query($data, $sql);

// Redirect to the check.html page
header("Location: index.php");
