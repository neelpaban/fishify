<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Set the recipient email address
    $to = "sarmahneelpaban@gmail.com";

    // Set the email subject
    $subject = "New Contact Form Submission";

    // Compose the email message
    $message = "Name: $name\nEmail: $email\nMessage:\n$message";

    // Set the headers
    $headers = "From: $email\r\nReply-To: $email";

    // Send the email
    if (mail($to, $subject, $message, $headers)) {
        // Email sent successfully
        echo "Thank you for contacting us. We will get back to you soon.";
    } else {
        // Email not sent
        echo "Sorry, there was an error. Please try again later.";
    }
}
?>
