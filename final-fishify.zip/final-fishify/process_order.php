<!-- process_order.php -->
<?php
require_once("db_connection.php"); // Include your database connection code
file_put_contents('post_data.log', print_r($_POST, true));
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get customer information from the form
    $name = $_POST["cname"];
    $phoneNumber = $_POST["phone_number"];
    $email = $_POST["email"];
    $address = $_POST["address"];

    // Get product information from the hidden fields
    $productId = $_POST["productId"];
    $productName = $_POST["productName"];
    $productPrice = $_POST["productPrice"];
    $quantity = $_POST["quantity"];

  


    // Insert data into the checkout table
    $insertQuery = "INSERT INTO checkout (name, phone_number, email, address, product_id, product_name, price, quantity, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)";
    $stmt = $dbConnection->prepare($insertQuery);
    $stmt->bind_param("ssssisdi", $name, $phoneNumber, $email, $address, $productId, $productName, $productPrice, $quantity);

    if ($stmt->execute()) {
        echo "Thanks!! Your order has been successfully placed.";
    } else {
        echo "Error processing the order: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$dbConnection->close();
?>
