<?php
session_start();
require_once("db_connection.php"); // Include your database connection code
// Assuming login is successful

$_SESSION['user_email'] = 'Admin'; // Assuming $email contains the user's email

?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
        .products {
            display: flex;
            flex-wrap: wrap;
            padding: auto;
            background: #fff;
  
  list-style: none;
  border-radius: 5px;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.04);
  margin-bottom: 40px;
  width: calc(100% / 3 - 30px);
  text-align: center;
        }

       
    

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

html {
  scroll-behavior: smooth;
}

body {
  background: #f2f2f2;
}

header {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 5;
  width: 100%;
  display: flex;
  justify-content: center;
  background: rgb(71, 71, 206);
}


.navbar {
  display: flex;
  padding: 0 10px;
  max-width: 1200px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
}

.navbar input#menu-toggler {
  display: none;
}

.navbar #hamburger-btn {
  cursor: pointer;
  display: none;
}

.navbar .all-links {
  display: flex;
  align-items: center;
}

.navbar .all-links li {
  position: relative;
  list-style: none;
}

.navbar .logo a {
  display: flex;
  align-items: center;
  margin-left: 0;
}

header a, footer a {
  margin-left: 40px;
  text-decoration: none;
  color: #fff;
  height: 100%;
  padding: 20px 0;
  display: inline-block;
}

header a:hover, footer a:hover {
  color: #ddd;
}



.content a:hover {
  color: #fff;
  background: rgba(255,255,255,0.3);
}

section {
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 80px 0 0;         
}

section h2 {
  font-size: 2rem;
}

section > p {
  text-align: center;
}

section .cards {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin-top: 50px;
  padding: 0 10px;
  justify-content: space-between;
}

section.about {
  margin: 0 auto;
  max-width: 1200px;
}



@media screen and (max-width: 860px) {
  .navbar .all-links {
    position: fixed;
    left: -100%;
    width: 300px;
    display: block;
    height: 100vh;
    top: 75px;
    background: #333;
    transition: left 0.3s ease;
  }

  .navbar #menu-toggler:checked~.all-links {
    left: 0;
  }

  .navbar .all-links li {
    font-size: 18px;
  }

  .navbar #hamburger-btn {
    display: block;
  }

  section > p {
    text-align: center;
  }

  section .cards .card {
    width: calc(100% / 2 - 15px);
    margin-bottom: 30px;
  }

@media screen and (max-width: 560px) {
  section .cards .card {
    width: 0%;
    margin-bottom: 30px;
  }
}
</style>
</head>
<body>
<header>
  <nav class="navbar">
    <h2 class="logo"><a href="index.php">FISHIFY</a></h2>
    <input type="checkbox" id="menu-toggler">
    <label for="menu-toggler" id="hamburger-btn">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24px" height="24px">
        <path d="M0 0h24v24H0z" fill="none"/>
        <path d="M3 18h18v-2H3v2zm0-5h18V11H3v2zm0-7v2h18V6H3z"/>
      </svg>
    </label>
    <ul class="all-links">
  <?php
  // Check if the user is logged in
  if (isset($_SESSION['loggedin'])) {
    // If logged in, display "Welcome" message and "Logout" button
    $userEmail = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
    echo '<li>Welcome, ' . htmlspecialchars($userEmail) . '</li>';
    echo '<li><a href="admin.html">Admin Panel</a></li>';
    echo '<li><a href="logout.php">Logout</a></li>';
  } else {
    // If not logged in, display "Login" link and other links
    echo '<li><a href="login1.php">LogIn</a></li>';
    echo '<li><a href="#aqp">Aquatic Plants</a></li>';
    echo '<li><a href="#contact">Contact Us</a></li>';
    echo '<li><a href="items_cart.php">Cart</a></li>';
  }
  ?>
</ul>


  </nav>
</header>
</body>
</html>
