<?php
session_start();
session_regenerate_id(true);
require_once("db_connection.php"); 

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FISHIFY | Dibrugarh</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
        .products {
            display: flex;
            flex-wrap: wrap;
            padding: auto;
            background: #fff;
  
  list-style: none;
  border-radius: 5px;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.04);
  margin-bottom: 40px;
  width: calc(100% / 3 - 30px);
  text-align: center;
        }

       
    

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

html {
  scroll-behavior: smooth;
}

body {
  background: #f2f2f2;
}

header {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 5;
  width: 100%;
  display: flex;
  justify-content: center;
  background: rgb(71, 71, 206);
}


.navbar {
  display: flex;
  padding: 0 10px;
  max-width: 1200px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
}

.navbar input#menu-toggler {
  display: none;
}

.navbar #hamburger-btn {
  cursor: pointer;
  display: none;
}

.navbar .all-links {
  display: flex;
  align-items: center;
}

.navbar .all-links li {
  position: relative;
  list-style: none;
}

.navbar .logo a {
  display: flex;
  align-items: center;
  margin-left: 0;
}

header a, footer a {
  margin-left: 40px;
  text-decoration: none;
  color: #fff;
  height: 100%;
  padding: 20px 0;
  display: inline-block;
}

header a:hover, footer a:hover {
  color: #ddd;
}

.homepage {
  height: 100vh;
  width: 100%;
  position: relative;
  border-radius: 5px;
  background: url("https://images.pexels.com/photos/3311083/pexels-photo-3311083.jpeg?auto=compress&cs=tinysrgb&w=1200");
  background-position: center 65%;
  background-size: cover;
}

.homepage::before {
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  background: rgba(0, 0, 0, 0.2);
}

.homepage .content {
  display: flex;
  height: 85%;
  z-index: 3;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}

.homepage .content h1 {
  font-size: 60px;
  font-weight: 700;
  margin-bottom: 10px;
}

.homepage .content .text {
  margin-bottom: 50px;
  color: #fff;
  font-size: 20px;
  text-align: center;
  text-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
}

.content a {
  color: #000;
  display: block;
  text-transform: uppercase;
  font-size: 18px;
  margin: 0 10px;
  padding: 10px 30px;
  border-radius: 5px;
  background: #fff;
  border: 2px solid #fff;
  transition: 0.4s ease;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
  text-decoration: none;
}

.content a:hover {
  color: #fff;
  background: rgba(255,255,255,0.3);
}

section {
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 80px 0 0;         
}

section h2 {
  font-size: 2rem;
}

section > p {
  text-align: center;
}

section .cards {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin-top: 50px;
  padding: 0 10px;
  justify-content: space-between;
}

section.about {
  margin: 0 auto;
  max-width: 1200px;
}

.about .company-info {
  margin-top: 30px;
}

.about h3 {
  margin: 30px 0 10px;
}

.about .team {
  text-align: left;
  width: 100%;
}

.about .team ul {
  padding-left: 20px;
}

.section .cards .card {
  background: #fff;
  padding: 40px 15px;
  list-style: none;
  border-radius: 5px;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.04);
  margin-bottom: 40px;
  width: calc(100% / 3 - 30px);
  text-align: center;
}

.fish .cards .card {
  padding: 0 0 20px;
}

.aqp .card img {
  width: 120px;
  height: 120px;
  margin-bottom: 20px;
  border-radius: 100%;
  object-fit: cover;
}

.cards .card p {
  padding: 0 15px;
  margin-top: 5px;
}

.about .row {
  padding: 0 10px;
}

.contact .row {
  margin: 60px 0 90px;
  display: flex;
  max-width: 1200px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
}

.contact .row .col {
  padding: 0 10px;
  width: calc(100% / 2 - 50px);
}

.contact .col p {
  margin-bottom: 10px;
}

.contact .col p i {
  color: #7a7a7a;
  margin-right: 10px;
}

.contact form input {
  height: 45px;
  margin-bottom: 20px;
  padding: 10px;
  width: 100%;
  font-size: 16px;
  outline: none;
  border: 1px solid #bfbfbf;
}

.contact form textarea {
  padding: 10px;
  width: 100%;
  font-size: 16px;
  height: 150px;
  outline: none;
  resize: vertical;
  border: 1px solid #bfbfbf;
}

.contact form button {
  margin-top: 10px;
  padding: 10px 20px;
  font-size: 17px;
  color: #fff;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  background: #333;
  transition: 0.2s ease;
}

.contact form button:hover {
  background: #525252;
}



@media screen and (max-width: 860px) {
  .navbar .all-links {
    position: fixed;
    left: -100%;
    width: 300px;
    display: block;
    height: 100vh;
    top: 75px;
    background: #333;
    transition: left 0.3s ease;
  }

  .navbar #menu-toggler:checked~.all-links {
    left: 0;
  }

  .navbar .all-links li {
    font-size: 18px;
  }

  .navbar #hamburger-btn {
    display: block;
  }

  section > p {
    text-align: center;
  }

  section .cards .card {
    width: calc(100% / 2 - 15px);
    margin-bottom: 30px;
  }

  .homepage .content h1 {
    font-size: 40px;
    font-weight: 700;
    margin-bottom: 10px;
    
  }

  .homepage .content .text {
    font-size: 17px;
  }

  .content a {
    font-size: 17px;
    padding: 9px 20px;
  }

  .contact .row {
    flex-direction: column;
  }

  .contact .row .col {
    width: 100%;
  }

  .contact .row .col:last-child {
    margin-top: 40px;
  }

  footer a {
    height: 0;
  }
}

@media screen and (max-width: 560px) {
  section .cards .card {
    width: 0%;
    margin-bottom: 30px;
  }
}

.aqp {
  display: flex;
  flex-wrap: nowrap; /* Prevent card wrapping to the next row */
  overflow-x: auto; /* Enable horizontal scrolling if there are too many cards */
  margin: 0 auto;
  max-width: 100%; /* Adjust the maximum width as needed */
  padding: 20px 0; /* Add padding as needed */
  justify-content: flex-start; /* Start from the left */
  align-items: center; /* Vertically align the cards */
  white-space: nowrap; /* Prevent cards from wrapping to the next row */
  scrollbar-width: thin; /* Add horizontal scrollbar if necessary */
}

.card {
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.04);
  min-width: 300px; /* Set a fixed minimum width for each card */
  text-align: center;
  margin-right: 20px; /* Add horizontal spacing between cards */
  white-space: normal; /* Allow text to wrap within the card */
  overflow: hidden; /* Hide overflow content */
}

.card:last-child {
  margin-right: 0; /* Remove margin for the last card */
}

.card img {
  max-width: 100%; /* Ensure images fit within the card */
  max-height: 200px;
  border-radius: 5px;
  object-fit: cover;
}

.card h3 {
  font-size: 1.5rem;
  margin-top: 10px;
}

.card p {
  font-size: 1rem;
  color: #555;
}

.row {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin: 10px 0;
}

@media screen and (max-width: 560px) {
  .row {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
}

 </style>
</head>
<body>
<body>
    <!-- Navbar Starts -->
    <?php
        include('navigation.php')
    ?>
 <section class="homepage">
      <div class="content">
        <div class="text">
          <h1>Fishes and Plants and Essentials</h1>
          <p>
            Discover top-quality fishes and plants for your home.</p>
        </div>
        <a href="#aqp">Scroll Below</a>
      </div>
    </section>

    <div class="aqp" id="aqp">
    <?php
    $query = "SELECT * FROM products";
    $result = $dbConnection->query($query);
    $productCount = 0;
    while ($product = $result->fetch_assoc()) {
        // Start a new row for every 4th product
    if ($productCount % 4 == 0) {
        echo "<div class='row'>";
    }

        echo "<section class='aqp'>";
        echo "<ul class='cards'>";
        echo "<li class='card'>";
        echo "<img src='" . $product["image_path"] . "' alt='" . $product["name"] . "' style='width: 170px; height: 180px;'>"; // Set the desired width and height here
        echo "<h3>" . $product["name"] . "</h3>";
        echo "<p>$" . $product["price"] . "/Piece</p>";
        echo "<button onclick='addToCart({$product['id']}, \"{$product['name']}\", {$product['price']})'>Add to Cart</button>";
        echo "<button><a href='product_details.php?id={$product['id']}'>View Details</a></button>";
        echo "<p>Product ID: " . $product["product_id"] . "</p>";
        $cartItemQuantity = 0; // Default to 0
    if (!empty($_SESSION['cart']) && isset($_SESSION['cart'][$product['id']])) {
        $cartItemQuantity = $_SESSION['cart'][$product['id']]['quantity'];
    }

    // Display quantity and buttons for incrementing and decrementing
    echo "<p>Quantity: <span id='quantity-{$product['id']}'>" . $cartItemQuantity . "</span></p>";
    echo "<button onclick='incrementCartItem({$product['id']})'>+</button>";
    echo "<button onclick='decrementCartItem({$product['id']})'>-</button>";

        echo "</li>";
        echo "</ul>";
        echo "</section>";
        // End the row for every 4th product or if it's the last product
    if ($productCount % 4 == 3 || $productCount == $result->num_rows - 1) {
        echo "</div>";
    }

    $productCount++;
}

    // Close the database connection
    $dbConnection->close();
    ?>
    </div>
    <section class="contact" id="contact">
      <h2>Contact Us</h2>
      <p>Reach out to us for any inquiries or feedback.</p>
      <div class="row">
        <div class="col information">
          <div class="contact-details">
            <p><i class="fas fa-map-marker-alt"></i> Chaliha Nagar, Tinsukia, Assam</p>
            <p><i class="fas fa-envelope"></i> sarmahneelpaban@gmail.com</p>
            <p><i class="fas fa-phone"></i> 6003465027</p>
            <p><i class="fas fa-clock"></i> Monday - Friday: 9:00 AM - 5:00 PM</p>
            <p><i class="fas fa-clock"></i> Saturday: 10:00 AM - 3:00 PM</p>
            <p><i class="fas fa-clock"></i> Sunday: Closed</p>
            <p><i class="fas fa-globe"></i> neelpabansarmah.cloud</p>
          </div>          
        </div>
        <div class="col form">
        <form action="update_counter.php" method="POST">
    <input type="text" name="name" placeholder="Name*" required>
    <input type="email" name="email" placeholder="Email*" required>
    <textarea name="message" placeholder="Message*" required></textarea>
    <button id="submit" type="submit">Send Message</button>
</form>
        </div>
      </div>
    </section>
    <script>
  // Function to increment the quantity
  function incrementCartItem(productId) {
    let quantityElement = document.querySelector(`#quantity-${productId}`);
    let currentQuantity = parseInt(quantityElement.textContent);
    currentQuantity++;
    quantityElement.textContent = currentQuantity;

    // Send an AJAX request to add the product to the cart
    addToCart(productId, 'increment');
  }

  // Function to decrement the quantity
  function decrementCartItem(productId) {
    let quantityElement = document.querySelector(`#quantity-${productId}`);
    let currentQuantity = parseInt(quantityElement.textContent);
    
    if (currentQuantity > 1) {
      currentQuantity--;
      quantityElement.textContent = currentQuantity;

      // Send an AJAX request to decrement the product from the cart
      addToCart(productId, 'decrement');
    }
  }

  // Function to add to cart using AJAX
  
    function addToCart(productId, productName, productPrice) {
        // Create a new XMLHttpRequest object
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'cart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        // Set up the data to be sent with the request
        const data = new URLSearchParams();
        data.append('action', 'addToCart');
        data.append('productId', productId);
        data.append('productName', productName);
        data.append('productPrice', productPrice);
        data.append('quantity', 1);

        // Send the data
        xhr.send(data);

        // Define a function to handle the response
        xhr.onload = function () {
            if (xhr.status === 200) {
                // You can handle the success response here, e.g., show a message to the user
                const response = JSON.parse(xhr.responseText);
                console.log(response.message);
            } else {
                // Handle any errors here
                console.error('An error occurred.');
            }
        };
    }
</script>



  </body>
</html>