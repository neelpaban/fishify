<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['productId'])) {
        $productId = $_POST['productId'];

        // Assuming $_SESSION['cart'] is an associative array with product IDs as keys
        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
            echo json_encode(['status' => 'success', 'message' => 'Item deleted successfully']);
            exit;
        }
    }
}

echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
exit;
?>
