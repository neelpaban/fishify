<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        .empty-cart {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Shopping Cart</h1>

    <table>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>

        <?php
        require_once("db_connection.php"); // Include your database connection code
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        
        
session_start();

// Check if the session variable 'cart' is not set, initialize it as an empty array
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Check if the action is to add to the cart
if ($_POST['action'] == 'addToCart') {
    // Extract the product details from the POST data
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $quantity = $_POST['quantity'];
    $productImage = $_POST['productImage'];

    // Check if the product already exists in the cart
    if (isset($_SESSION['cart'][$productId])) {
        // Increment the quantity if the product exists
        $_SESSION['cart'][$productId]['quantity'] += $quantity;
    } else {
        // Add a new entry to the cart if the product does not exist
        $_SESSION['cart'][$productId] = array(
            'name' => $productName,
            'price' => $productPrice,
            'quantity' => $quantity,
            'image' => $productImage
        );
    }

    // Return a response
    echo json_encode(array('message' => 'Product added to cart successfully'));
}
?>


    </table>
</body>
</html>
