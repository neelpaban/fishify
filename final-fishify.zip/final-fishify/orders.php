<?php
        include('navigation.php')
    ?>

<?php

require_once("db_connection.php");

// Check if the form is submitted (checkbox is clicked)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_order'])) {
    // Ensure the order ID is provided
    if (isset($_POST['order_id'])) {
        $orderId = $_POST['order_id'];

        // Perform the deletion based on the order ID
        $deleteQuery = "DELETE FROM checkout WHERE id = ?";
        $deleteStmt = $dbConnection->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $orderId);
        
        if ($deleteStmt->execute()) {
            // Order deleted successfully
        } else {
            echo "Error deleting order: " . $deleteStmt->error;
        }

        // Close the prepared statement
        $deleteStmt->close();
    }
}

$query = "SELECT * FROM checkout";
$result = $dbConnection->query($query);

// Check if there are any orders
if ($result->num_rows > 0) {
    echo "<!DOCTYPE html>";
    echo "<html lang='en'>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>Orders</title>";
    echo "<style>";
    echo "body { font-family: Arial, sans-serif; background-color: #f2f2f2; margin: 0; padding: 20px; }";
    echo "table { border-collapse: collapse; width: 100%; margin-top: 20px; }";
    echo "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }";
    echo "th { background-color: #f2f2f2; }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    echo "<h1>Orders</h1>";
    echo "<form method='post'>";
    echo "<table>";
    echo "<tr><th>Name</th><th>Phone Number</th><th>Email</th><th>Address</th><th>Product Name</th><th>Product ID</th><th>Price</th><th>Quantity</th><th>Action</th><th>Remarks</th></tr>";

    // Fetch and display 
    while ($row = $result->fetch_assoc()) {
        echo "<tr id='row{$row['id']}'>";
        echo "<td>{$row['name']}</td>";
        echo "<td>{$row['phone_number']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "<td>{$row['address']}</td>";
        echo "<td>{$row['product_name']}</td>";
        echo "<td>{$row['product_id']}</td>";
        echo "<td>{$row['price']}</td>";
        echo "<td>{$row['quantity']}</td>";
        $doneText = $row['remarks'] === 'DONE' ? 'Done' : '<button onclick="markOrderAsDone(' . $row['id'] . ', event)">Mark as Done</button>';

        echo "<td>{$doneText}</td>";
        
        echo "<td id='remarks{$row['id']}'>{$row['remarks']}</td>";
        echo "</tr>";
    }

    echo "</table>";
    echo "</form>";
    echo "<script>
    function markOrderAsDone(orderId, event) {
        var remarksCell = document.getElementById('remarks' + orderId);
        remarksCell.innerHTML = 'DONE';
    
        // Prevent the default behavior of the button click
        event.preventDefault();
    
        // Send an AJAX request to mark the order as done
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'mark_order_as_done.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            if (xhr.status !== 200) {
                console.error('Error marking order as done: ' + xhr.responseText);
            }
        };
        xhr.send('order_id=' + orderId);
    }
</script>";

    echo "</body>";
    echo "</html>";
} else {
    echo "No orders available.";
}

// Close the database connection
$dbConnection->close();
?>