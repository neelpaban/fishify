<?php
require_once("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['order_id'])) {
    $orderId = $_POST['order_id'];

    // Perform the deletion based on the order ID
    $deleteQuery = "DELETE FROM checkout WHERE id = ?";
    $deleteStmt = $dbConnection->prepare($deleteQuery);
    $deleteStmt->bind_param("i", $orderId);

    if ($deleteStmt->execute()) {
        // Order deleted successfully
        echo "Order deleted successfully";
    } else {
        header('HTTP/1.1 500 Internal Server Error');
        echo "Error deleting order: " . $deleteStmt->error;
    }

    // Close the prepared statement
    $deleteStmt->close();
}

// Close the database connection
$dbConnection->close();
?>
