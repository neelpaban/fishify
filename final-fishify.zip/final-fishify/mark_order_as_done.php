<?php
require_once("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['order_id'])) {
    $orderId = $_POST['order_id'];

    // Update the remarks in the database
    $updateQuery = "UPDATE checkout SET remarks = 'DONE' WHERE id = ?";
    $updateStmt = $dbConnection->prepare($updateQuery);
    $updateStmt->bind_param("i", $orderId);

    if ($updateStmt->execute()) {
        // Success
        echo "Order marked as DONE.";
    } else {
        // Error
        echo "Error marking order as DONE: " . $updateStmt->error;
    }

    $updateStmt->close();
} else {
    // Invalid request
    echo "Invalid request.";
}

// Close the database connection
$dbConnection->close();
?>
