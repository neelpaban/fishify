<?php
session_start();


// Include your database connection code
require_once("db_connection.php");

// Get user-specific information from the database
$email = $_SESSION['email']; // Assuming you store the user's email in the session

// Retrieve user details
$userQuery = "SELECT * FROM registration WHERE email = ?";
$userStmt = $dbConnection->prepare($userQuery);
$userStmt->bind_param("s", $email);
$userStmt->execute();
$userResult = $userStmt->get_result();
$user = $userResult->fetch_assoc();
$userStmt->close();

// Retrieve user's cart items
$cartQuery = "SELECT * FROM cart WHERE user_id = ?";
$cartStmt = $dbConnection->prepare($cartQuery);
$cartStmt->bind_param("i", $user['id']); // Assuming 'id' is the user ID in your users table
$cartStmt->execute();
$cartResult = $cartStmt->get_result();
$cartItems = $cartResult->fetch_all(MYSQLI_ASSOC);
$cartStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Page</title>
    <!-- Include your CSS styles or link to an external stylesheet if needed -->
</head>
<body>
    <h1>Welcome, <?php echo $user['email']; ?>!</h1>
    <!-- Your content for the user page -->

    <p>This is the user page content. Your email: <?php echo $user['email']; ?></p>

    <!-- Display user's cart items -->
    <h2>Your Cart</h2>
    <ul>
        <?php foreach ($cartItems as $item): ?>
            <li><?php echo $item['product_name']; ?> - $<?php echo $item['price']; ?></li>
        <?php endforeach; ?>
    </ul>

    <!-- Include your JavaScript files or scripts if needed -->

    <!-- Logout link -->
    <a href="logout.php">Logout</a>
</body>
</html>
