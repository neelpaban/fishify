<!-- Example: product_details.php -->

<?php
require_once("db_connection.php"); // Include your database connection code

// Get the product ID from the URL
$productId = $_GET['id'];

// Fetch product details from the database
$query = "SELECT * FROM products WHERE id = $productId";
$result = $dbConnection->query($query);
$product = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .product-container {
            display: flex;
            max-width: 800px;
            margin: auto;
        }

        .product-image {
            flex: 1;
            margin-right: 20px;
        }

        .product-details {
            flex: 1;
        }

        .product-details h2 {
            margin-bottom: 10px;
        }

        .product-details p {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<?php
        include('navigation.php')
    ?>

<div class="product-container">
    <div class="product-image">
        <?php
        // Display product image
        if ($product && isset($product['image_path'])) {
            echo "<img src='{$product['image_path']}' alt='{$product['name']}' style='max-width: 100%;'>";
        } else {
            echo "<p>No image available</p>";
        }
        ?>
    </div>
    <div class="product-details">
        <?php
        // Display product details
        if ($product) {
            echo "<h2>{$product['name']}</h2>";
            echo "<p>{$product['description']}</p>";
            echo "<p>Price: {$product['price']}</p>";
        } else {
            echo "<p>Product not found</p>";
        }
        ?>
    </div>
</div>

</body>
</html>

<?php
// Close the database connection
$dbConnection->close();
?>
