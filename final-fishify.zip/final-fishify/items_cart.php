<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 80px;
            text-align: justify;
            margin-left: auto;
            margin-right: auto;
        }

        .card {
            background: #fff;
  padding: 20px;
  margin-top: 10px;
  border-radius: 10px;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.04);
  min-width: 300px; /* Set a fixed minimum width for each card */
  text-align: center;
  /*margin-right: 20px; */ /* Add horizontal spacing between cards */
  white-space: normal; /* Allow text to wrap within the card */
  overflow: hidden;
  margin-left: auto;
            margin-right: auto;
        }

        .card img {
            max-width: 100%;
            max-height: 100px;
            border-radius: 12px;
            margin-bottom: 10px;
            object-fit: cover;
        }

        button {
            padding: 8px;
            margin-top: 10px;
            cursor: pointer;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<?php
        include('navigation.php')
    ?>

<?php
session_start();
session_regenerate_id(true);
require_once("db_connection.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


function getUserIP() {
    // Check for shared Internet connections
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Check if a session exists for the user's IP address
$userIP = getUserIP();
if (!isset($_SESSION['user_ip']) || $_SESSION['user_ip'] !== $userIP) {
    // Start a new session
    session_regenerate_id(true); // Generate a new session ID for security
    $_SESSION = array(); // Reset the session data
    $_SESSION['user_ip'] = $userIP; // Store the user's IP address in the session

    // Initialize an empty cart
    $_SESSION['cart'] = array();
}
?>

<?php
// Check if the session variable 'cart' is set
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    // Loop through the cart items and display them
    foreach ($_SESSION['cart'] as $productId => $product) {
    ?>
        <div class="card">
        <td><img src="<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="max-width: 50px; max-height: 50px;"></td>
            <h4><?php echo $product['name']; ?></h4>
            <p>$<?php echo $product['price']; ?></p>
            <p>Quantity: <?php echo $product['quantity']; ?></p>
            <button onclick='deleteCartItem(<?php echo $productId; ?>)'>Delete</button>
            <button onclick='buyNow(<?php echo $productId; ?>)' class="buy-now-button">Buy Now</button>
        </div>
    <?php
    }
} else {
    echo "Cart is empty.";
}
?>
<script>
  function deleteCartItem(productId) {
    // Send an AJAX request to delete the product from the cart
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'delete_cart_item.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    const data = new URLSearchParams();
    data.append('productId', productId);
    
    xhr.send(data);

    // Reload the page or update the cart display as needed
    xhr.onload = function () {
      if (xhr.status === 200) {
        // You can handle the success response here, e.g., reload the page
        location.reload();
      } else {
        console.error('An error occurred.');
      }
    };
  }
  function buyNow(productId) {
    // Redirect to the checkout page with the product ID
    window.location.href = 'checkout.php?productId=' + productId;
}
</script>
</body>
</html>
