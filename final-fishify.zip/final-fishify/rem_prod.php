<?php
require_once("db_connection.php"); // Include your database connection code

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["remove_product"])) {
    $product_id = $_POST["product_id"];
    
    // You can add validation and security checks here as needed

    $query = "DELETE FROM products WHERE product_id=?";
    $stmt = $dbConnection->prepare($query);
    $stmt->bind_param("i", $product_id);

    if ($stmt->execute()) {
        echo "Product removed successfully.";
    } else {
        echo "Error removing product: " . $stmt->error;
    }

    $stmt->close();
}

// Close the database connection
$dbConnection->close();
?>
